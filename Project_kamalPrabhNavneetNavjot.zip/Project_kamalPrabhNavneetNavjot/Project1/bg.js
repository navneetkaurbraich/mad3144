function randombg(){
  var random= Math.floor(Math.random() * 6) + 0;
  var bigSize = ["url('images/background.jpg')",
                 "url('images/back.jpg')",
                 "url('images/back2.jpg')",
                 "url('images/back3.jpg')",
                 "url('images/back4.jpg')",
                 "url('images/back5.jpg')"];
  document.getElementById("random").style.backgroundImage=bigSize[random];
}

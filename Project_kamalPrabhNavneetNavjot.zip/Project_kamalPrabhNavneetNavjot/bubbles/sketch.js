

var particle = [];
var circle;
var h;
var c;
function setup() {
 c =  createCanvas(900,800);
 circle=  createDiv();
circle.position(450,350);
circle.style("border","1px solid red");
circle.style("width","200px");
circle.style("height","200px");
circle.style("border-radius","400px");
circle.mousePressed(press);
h = createElement("h1","whats in circle");
h.position(420,600);

//  for(var i =0 ;i <5;i++){
//  circles[i] = new circle();
//  }
}

function draw() {
  //background(0);
  //for(var i =0 ;i <circles.length;i++){
 //circles[i].move();
  //circles[i].display();
  //circles[i].update();

//  }
//  if(circles.length >15){
  //  circles.splice(0,1);
//  ellipse(450,350,20,20)

  }
  function press(){
    circle.style("display","none");
    h.style("display","none");
      move();
       c.mousePressed(move);
       c.mouseMoved(move);

  }

  //function mouseDragged(){
//    move();
//  }





particleIndex = 0 ,
particlenum = 50;
function move(){
function particles(){
  this.x = event.pageX - canvas.offsetLeft ;
  this.y = event.pageY - canvas.offsetLeft ;
  this.vx = Math.random() * 6 - 5;
  this.vy = Math.random() * 9 - 5;
  this.gravity = 0.10;
  particleIndex++;
  particle[particleIndex] = this;
  this.id = particleIndex;
  this.life = 10;
  this.maxLife = Math.random() *50 + 10;
  this.color = "hsl("+parseInt(Math.random()*455,10)+",80%,50%)";
  //Random g = new Random();


}


particles.prototype.draw = function(){
  this.x += this.vx;
  this.y += this.vy;
  if(Math.random()<0.2){

    this.vx = Math.random() * 6 - 5;
    this.vy = Math.random() * 9 - 5;
  }

//  this.vx += this.gravity;
  this.life++;
  if(this.life >= this.maxLife){
    delete particle[this.id];
  }
  fill(this.color);
  ellipse(this.x,this.y,15,30);

};
for(var i = 0;i<particlenum;i++){
  new particles();
}
setInterval(function(){
fill("white");
 rect(5,0,canvas.width,canvas.height);

  for(var i in particle){
    particle[i].draw();
  }
}, 30);


}

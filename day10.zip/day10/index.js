//1.  create a context variable and setup your canvas

//1a get the context
 var context=document.getElementById("main").getContext("2d");

//1b setup your brush (width and color)
context.lineWidth = 3;
context.strokeStyle = "#0000FF";

//2. setup your main canvas variable
var mainCanvas=document.getElementById("main");

var startDrawing =false;


// global variable
var isClick = 0;

//3. detect mouse event
mainCanvas.addEventListener("mousedown",function(event){
//detect a Click
isClick = 0;
startDrawing = true;
})

mainCanvas.addEventListener("mouseup",function(){

  startDrawing = false;
//detect the difference between a click and the end of a drawing
if (isClick==0) {
  console.log("Person is clicking");

  //insert  code to draw a rectangle
//get the(x,y) position
  var x=event.pageX;
  var y=event.pageY;

  //
  var brushSize = context.lineWidth;
  context.fillRect(x,y,brushSize,brushSize)
}
  else if(isClick == 1){
    console.log("person is dragging")
    context.beginPath();
  }
})

mainCanvas.addEventListener("mousemove",function(event){

  isClick = 1;

if(startDrawing==true){
  //detect your mouse (x,y)
  var x=event.pageX ;
  var y=event.pageY;
  console.log(x+","+y);
  context.lineTo(x,y);
  context.closePath();
  context.stroke();

  context.moveTo(x,y);
}
});

mainCanvas.addEventListener("mouseleave",function(){
  startDrawing = false;
})

//user interface nonsense

document.getElementById("newDrawing").addEventListener("click",function(){
  context.clearRect(0,0,mainCanvas.width,mainCanvas.height);
});

document.getElementById("erase").addEventListener("click",function(){
  context.strokeStyle="#ffffff";
});

document.getElementById("pink").addEventListener("click",function(){
  context.strokeStyle = "#FFC0CB";
});

document.getElementById("yellow").addEventListener("click",function(){
  context.strokeStyle = "#FFEB3B";
});

//change brush brushSize
document.getElementById("slider").addEventListener("change",function(){
  var sliderValue = this.value;
  console.log(sliderValue);

  //userinterface nonsense
  context.lineWidth = sliderValue;
  document.getElementById("brushSize").innerHTML = sliderValue;

  });
});
